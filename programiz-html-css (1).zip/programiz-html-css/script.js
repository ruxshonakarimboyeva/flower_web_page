function showAlert() {
  alert("🌸 Welcome to the Flowers shop!");
}
